import React from "react";

const Home = () => {
  return <div className="Home"></div>;
};

export default Home;
