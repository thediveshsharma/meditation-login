import React from "react";

const Error = () => {
  return (
    <div className="Error">
      <h1>Error</h1>
    </div>
  );
};

export default Error;
