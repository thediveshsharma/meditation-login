export default {
  SIDEBAR: {
    WIDTH: 240,
    MINI_WIDTH: 74, //MAYBE
  },

  BREAKPOINTS: {
    MOBILE: 1190,
  },
  JWT_TOKEN: "jwt_token",
};
