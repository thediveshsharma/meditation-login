# Todo:

1. Adaptive Design
2. navbar work-> later , back btn for search etc
3. Sidebars

4. Can create a all new Vertical Layout...or anything that's new and innovative

5. getting that thing when loading the page
